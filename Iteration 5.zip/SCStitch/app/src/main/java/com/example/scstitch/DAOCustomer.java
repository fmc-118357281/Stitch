package com.example.scstitch;

import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import java.util.HashMap;

//code from youtube video https://www.youtube.com/watch?v=741QCymuky4

public class DAOCustomer {
    private DatabaseReference databaseReference;

    //
    public DAOCustomer() {
        FirebaseDatabase db = FirebaseDatabase.getInstance("https://scstitch-5ae62-default-rtdb.firebaseio.com/");
        databaseReference = db.getReference(Customer.class.getSimpleName());
    }

    //push data onto user database as child node "customer info"
    public Task<Void> addUser(String userid, Customer user1) {
        return databaseReference.child(userid).child("Customer information").setValue(user1);

    }

    //push data onto user database as child node "customer measurements"
    public Task<Void> addMeasurements(String userid, CustomerMeasurements user1) {
        return databaseReference.child(userid).child("Customer measurements").setValue(user1);

    }

    //for updating database
    public Task<Void> update(String key, HashMap<String ,Object> hashMap)
    {
        //call child from database
        return databaseReference.child(key).updateChildren(hashMap);
    }
    public Task<Void> remove(String key)
    {
        return databaseReference.child(key).removeValue();
    }
    public Query get()
    {
        return databaseReference;
    }
}
