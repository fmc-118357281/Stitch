package com.example.scstitch;

import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;

import java.util.HashMap;

//code from youtube video https://www.youtube.com/watch?v=741QCymuky4

public class DAOOrders {
    private DatabaseReference databaseReference;

    //
    public DAOOrders() {
        FirebaseDatabase db = FirebaseDatabase.getInstance("https://scstitch-5ae62-default-rtdb.firebaseio.com/");
        databaseReference = db.getReference(Orders.class.getSimpleName());
    }

    //push data onto user database
    public Task<Void> addOrder(String userid, Orders order) {
        return databaseReference.child(userid).setValue(order);

    }

    //push data onto user database
    public Task<Void> uploadToFirebase(String userid, Orders order) {
        return databaseReference.child(userid).setValue(order);

    }


}
