package com.example.scstitch;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

public class TailorProfileActivity extends AppCompatActivity {

    //all code from https://www.youtube.com/watch?v=MnJg1f25h_g&list=PLnisUReSm0-kNhfXJHymlIFeyGYHj87tP&index=14

    private TextView tvWelcome, tvFullName, tvAddress, tvProficiency, tvEmail, tvQualification, tvRatePerHour;
    private ProgressBar progressBar;
    private String fullName, address, proficiency, email, qualification, ratePerHour;
    private ImageView imageView;
    private FirebaseAuth authProfile;
    private Uri uriImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_tailor_profile);

        getSupportActionBar().setTitle("Home");

        tvWelcome = findViewById(R.id.tvWelcome);
        tvFullName = findViewById(R.id.tvFullName);
        tvAddress = findViewById(R.id.tvAddress);
        tvProficiency = findViewById(R.id.tvProficiency);
        tvEmail = findViewById(R.id.tvEmail);
        tvQualification = findViewById(R.id.tvQualification);
        tvRatePerHour = findViewById(R.id.tvRatePerHour);
        progressBar = findViewById(R.id.progressBar);

        authProfile = FirebaseAuth.getInstance();
        FirebaseUser firebaseUser = authProfile.getCurrentUser();

        imageView = findViewById(R.id.imageView);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(TailorProfileActivity.this, UploadProfileImageActivity.class));
            }
        });


        if (firebaseUser == null) {
            Toast.makeText(TailorProfileActivity.this, "Error occurred, Profile details unattainable at this moment", Toast.LENGTH_LONG).show();
        } else {
            progressBar.setVisibility(View.VISIBLE);
            showUserProfile(firebaseUser);

        }
    }

    private void showUserProfile(FirebaseUser firebaseUser){
        progressBar.setVisibility(View.VISIBLE);
        String userID = firebaseUser.getUid();

        //extracting user reference from database
        DatabaseReference referenceProfile = FirebaseDatabase.getInstance("https://scstitch-5ae62-default-rtdb.firebaseio.com").getReference("Tailor");
        referenceProfile.child(userID).addListenerForSingleValueEvent(new ValueEventListener(){
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot){
                Tailor tailor = snapshot.getValue(Tailor.class);
                if (tailor != null){
                    fullName = tailor.getFullName();
                    proficiency = tailor.getProficiency();
                    email = tailor.getEmail();
                    address = tailor.getAddress();
                    qualification = tailor.getQualification();
                    ratePerHour = tailor.getRatePerHour();

                    progressBar.setVisibility(View.INVISIBLE);

                    tvWelcome.setText("Welcome, " + fullName);
                    tvFullName.setText(fullName);
                    tvAddress.setText(address);
                    tvProficiency.setText(proficiency);
                    tvEmail.setText(email);
                    tvQualification.setText(qualification);
                    tvRatePerHour.setText("€" + ratePerHour + "/hour");

                    //set user PP
                    Uri uri = firebaseUser.getPhotoUrl();
                    Picasso.with(TailorProfileActivity.this)
                            .load(uri)
                            .into(imageView);
                } else{
                    Toast.makeText(TailorProfileActivity.this, "Something went wrong", Toast.LENGTH_LONG).show();
                }
                }


            //triggered in event of failure due to firebase rules
            @Override
            public void onCancelled(@NonNull DatabaseError error){
                Toast.makeText(TailorProfileActivity.this, "Something went wrong", Toast.LENGTH_LONG).show();
            }


        });


    }


    //create action bar menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //inflate menu items
        getMenuInflater().inflate(R.menu.tailor_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    //when any menu item selected
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item){
        int id = item.getItemId();

        if (id == R.id.menu_refresh){
            //refresh
            startActivity(getIntent());
            finish();
            overridePendingTransition(0, 0);
        } else if (id == R.id.menu_edit){
            Intent intent = new Intent(TailorProfileActivity.this, TailorCreateProfileActivity.class);
            startActivity(intent);
        } else if (id == R.id.menu_orders){
            Intent intent = new Intent(TailorProfileActivity.this, TailorViewOrdersActivity.class);
            startActivity(intent);
        }else if (id == R.id.menu_logout) {
            authProfile.signOut();
            Toast.makeText(TailorProfileActivity.this, "Signed out", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(TailorProfileActivity.this, HomeActivity.class);
            startActivity(intent);
            finish(); // close user profile activity
        }else {
            Toast.makeText(TailorProfileActivity.this, "Something went wrong", Toast.LENGTH_LONG).show();
        }
        return super.onOptionsItemSelected(item);
    }
}

