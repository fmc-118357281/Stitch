package com.example.scstitch;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

public class CustomerProfileActivity extends AppCompatActivity {

    //all code from https://www.youtube.com/watch?v=MnJg1f25h_g&list=PLnisUReSm0-kNhfXJHymlIFeyGYHj87tP&index=14

    private TextView tvWelcome, tvFullName, tvAddress, tvDOB, tvPhone, tvGender;
    private ProgressBar progressBar;
    private String fullName, address, dob, phone, gender;
    private ImageView imageView;
    private FirebaseAuth authProfile;
    private Button btnCreateOrder, btnAddMeasurements;
    private Uri uriImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_customer_profile);

        getSupportActionBar().setTitle("Profile");

        tvWelcome = findViewById(R.id.tvWelcome);
        tvFullName = findViewById(R.id.tvFullName);
        tvGender = findViewById(R.id.tvGender);
        tvAddress = findViewById(R.id.tvAddress);
        tvDOB = findViewById(R.id.tvDOB);

        tvPhone = findViewById(R.id.tvPhone);
        progressBar = findViewById(R.id.progressBar);
        btnAddMeasurements = findViewById(R.id.btnAddMeasurements);

        btnCreateOrder = findViewById(R.id.btnCreateOrder);

        authProfile = FirebaseAuth.getInstance();
        FirebaseUser firebaseUser = authProfile.getCurrentUser();

        imageView = findViewById(R.id.imageView);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(CustomerProfileActivity.this, UploadProfileImageActivity.class));
            }
        });


        if (firebaseUser == null) {
            Toast.makeText(CustomerProfileActivity.this, "Error occurred, Profile details unattainable at this moment", Toast.LENGTH_LONG).show();
        } else {
            progressBar.setVisibility(View.VISIBLE);
            showUserProfile(firebaseUser);

        }
    }

    private void showUserProfile(FirebaseUser firebaseUser) {
        //progressBar.setVisibility(View.VISIBLE);
        String userID = firebaseUser.getUid();

        //extracting user reference from database
        DatabaseReference referenceProfile = FirebaseDatabase.getInstance("https://scstitch-5ae62-default-rtdb.firebaseio.com").getReference("Customer");
        referenceProfile.child(userID).child("Customer information").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Customer customer = snapshot.getValue(Customer.class);
                if (customer != null) {
                    fullName = customer.getFullName();
                    gender = customer.getGender();
                    dob = customer.getDOB();
                    phone = customer.getPhone();
                    address = customer.getAddress();

                    progressBar.setVisibility(View.INVISIBLE);

                    tvWelcome.setText("Welcome, " + fullName);
                    tvFullName.setText(fullName);
                    tvGender.setText(gender);
                    tvAddress.setText(address);
                    tvDOB.setText(dob);
                    tvPhone.setText(phone);

                    //set user PP
                    Uri uri = firebaseUser.getPhotoUrl();
                    Picasso.with(CustomerProfileActivity.this).load(uri).into(imageView);
                } else{
                Toast.makeText(CustomerProfileActivity.this, "Something went wrong", Toast.LENGTH_LONG).show();
                }
            }

            //triggered in event of failure due to firebase rules
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(CustomerProfileActivity.this, "Something went wrong", Toast.LENGTH_LONG).show();
            }

        });

        //create new order button functionality
        btnCreateOrder.setOnClickListener(view -> {
            startActivity(new Intent(CustomerProfileActivity.this, CreateOrderActivity.class));
        });

        //create new order button functionality
        btnAddMeasurements.setOnClickListener(view -> {
            startActivity(new Intent(CustomerProfileActivity.this, CustomerMeasurementsActivity.class));
        });



    }

    //create action bar menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //inflate menu items
        getMenuInflater().inflate(R.menu.customer_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    //when any menu item selected
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item){
        int id = item.getItemId();

        if (id == R.id.menu_refresh){
            //refresh
            startActivity(getIntent());
            finish();
            overridePendingTransition(0, 0);
        } else if (id == R.id.menu_edit){
            Intent intent = new Intent(CustomerProfileActivity.this, EditCustomerProfileActivity.class);
            startActivity(intent);
        } else if (id == R.id.menu_orders){
            Intent intent = new Intent(CustomerProfileActivity.this, OrderSummaryActivity.class);
            startActivity(intent);
        } else if (id == R.id.menu_measurements) {
            Intent intent = new Intent(CustomerProfileActivity.this, CustomerMeasurementsActivity.class);
            startActivity(intent);
        }else if (id == R.id.menu_logout) {
            authProfile.signOut();
            Toast.makeText(CustomerProfileActivity.this, "Signed out", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(CustomerProfileActivity.this, HomeActivity.class);
            startActivity(intent);
            finish(); // close user profile activity
        }else {
            Toast.makeText(CustomerProfileActivity.this, "Something went wrong", Toast.LENGTH_LONG).show();
        }
        return super.onOptionsItemSelected(item);
    }
}
