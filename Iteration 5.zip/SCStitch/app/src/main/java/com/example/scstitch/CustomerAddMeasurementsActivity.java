package com.example.scstitch;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class CustomerAddMeasurementsActivity extends AppCompatActivity {

    //code found on youtube video https://www.youtube.com/watch?v=741QCymuky4
private FirebaseAuth authProfile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FirebaseUser currentFirebaseUser = FirebaseAuth.getInstance().getCurrentUser() ;
        Toast.makeText(this, "" + currentFirebaseUser.getUid(), Toast.LENGTH_SHORT).show();

        // connect to xml file
        setContentView(R.layout.activity_customer_add_measurements);

        //save measurements button functionality
        Button btnSaveMeasurements = findViewById(R.id.btnSaveMeasurements);
        //create database connection
        DAOCustomer dao = new DAOCustomer();

        getSupportActionBar().setTitle("Add measurements");

        //set which ids relate to each variable
        final EditText etDressSize = findViewById(R.id.etDressSize);
        final EditText etWaist = findViewById(R.id.etWaist);
        final EditText etHips = findViewById(R.id.etHips);
        final EditText etInseam = findViewById(R.id.etInseam);
        final EditText etBust = findViewById(R.id.etBust);
        final EditText etAdditional = findViewById(R.id.etAdditional);
        final ProgressBar progressBar = findViewById(R.id.progressBar);


        btnSaveMeasurements.setOnClickListener(v ->
        {

            //create strings
            CustomerMeasurements user1 = new CustomerMeasurements(etDressSize.getText().toString(), etWaist.getText().toString(), etHips.getText().toString(), etInseam.getText().toString(), etBust.getText().toString(), etAdditional.getText().toString());

            String dressSize = etDressSize.getText().toString();
            String Waist = etWaist.getText().toString();
            String Hips = etHips.getText().toString();
            String Inseam = etInseam.getText().toString();
            String Bust = etBust.getText().toString();

            //if successful, bring to profile activity
            dao.addMeasurements(currentFirebaseUser.getUid(), user1).addOnSuccessListener(suc ->
            {
                //conditions to be met in order to register user
                if  (etDressSize.length() > 2) {
                    etDressSize.setError("Invalid dress size");
                    etDressSize.requestFocus();
                }else if (TextUtils.isEmpty(dressSize)) {
                    etDressSize.setError("Dress size cannot be empty");
                    etDressSize.requestFocus();
                }else if (TextUtils.isEmpty(Waist)) {
                    etWaist.setError("Waist measurement cannot be empty");
                    etWaist.requestFocus();
                }else if (TextUtils.isEmpty(Hips)) {
                    etHips.setError("Hips measurement cannot be empty");
                    etHips.requestFocus();
                }else if (TextUtils.isEmpty(Inseam)) {
                    etInseam.setError("Inseam measurement cannot be empty");
                    etInseam.requestFocus();
                }else if (TextUtils.isEmpty(Bust)) {
                    etBust.setError("Bust measurement cannot be empty");
                    etBust.requestFocus();
                }else {
                    progressBar.setVisibility(View.VISIBLE);
                    Toast.makeText(this, "Your measurements have been saved!", Toast.LENGTH_SHORT).show();


                    // bring user to profile page
                    // prevent user from returning back to create profile activity once registration successful
                    Intent intent = new Intent(CustomerAddMeasurementsActivity.this, CustomerMeasurementsActivity.class);
                    intent.setFlags((intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK
                            | Intent.FLAG_ACTIVITY_NEW_TASK));
                    startActivity(intent);
                    finish();
                }
            }).addOnFailureListener(er ->
            {
                Toast.makeText(this, "Error saving measurements" + er.getMessage(), Toast.LENGTH_SHORT).show();
            });
            progressBar.setVisibility(View.GONE);

        });

    }

    //create action bar menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //inflate menu items
        getMenuInflater().inflate(R.menu.order_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    //when any menu item selected
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item){
        int id = item.getItemId();

        if (id == R.id.menu_refresh){
            //refresh
            startActivity(getIntent());
            finish();
            overridePendingTransition(0, 0);
        } else if (id == R.id.menu_profile){
            Intent intent = new Intent(CustomerAddMeasurementsActivity.this, CustomerProfileActivity.class);
            startActivity(intent);
        }else if (id == R.id.menu_logout) {
            authProfile.signOut();
            Toast.makeText(CustomerAddMeasurementsActivity.this, "Signed out", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(CustomerAddMeasurementsActivity.this, HomeActivity.class);
            startActivity(intent);
            finish(); // close user profile activity
        }else {
            Toast.makeText(CustomerAddMeasurementsActivity.this, "Something went wrong", Toast.LENGTH_LONG).show();
        }
        return super.onOptionsItemSelected(item);
    }

}



