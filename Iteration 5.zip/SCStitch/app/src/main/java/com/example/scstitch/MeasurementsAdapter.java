package com.example.scstitch;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class MeasurementsAdapter extends RecyclerView.Adapter<MeasurementsAdapter.MyViewHolder> {
    Context context;
    ArrayList<CustomerMeasurements> customerMeasurements;

    public MeasurementsAdapter(Context c, ArrayList<CustomerMeasurements> p){
        customerMeasurements = p;
        context = c;
    }

    @NonNull
    @Override
    public MeasurementsAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MeasurementsAdapter.MyViewHolder(LayoutInflater.from(context).inflate(R.layout.measurement_info,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull MeasurementsAdapter.MyViewHolder holder, int position) {

        //connect to ui
        holder.tvDressSize.setText(customerMeasurements.get(position).getDressSize());
        holder.tvWaist.setText(customerMeasurements.get(position).getWaist());
        holder.tvHips.setText(customerMeasurements.get(position).getHips());
        holder.tvInseam.setText(customerMeasurements.get(position).getInseam());
        holder.tvBust.setText(customerMeasurements.get(position).getBust());
        holder.tvAdditional.setText(customerMeasurements.get(position).getAdditional());
    }

    @Override
    public int getItemCount() {

        return customerMeasurements.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder{

        //declare vars
        TextView tvDressSize, tvWaist, tvHips, tvInseam, tvBust, tvAdditional;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            tvDressSize = (TextView) itemView.findViewById(R.id.tvDressSize);
            tvWaist = (TextView) itemView.findViewById(R.id.tvWaist);
            tvHips = (TextView) itemView.findViewById(R.id.tvHips);
            tvInseam = (TextView) itemView.findViewById(R.id.tvInseam);
            tvBust = (TextView) itemView.findViewById(R.id.tvBust);
            tvAdditional = (TextView) itemView.findViewById(R.id.tvAdditional);
        }


        }
    }



