package com.example.scstitch;

import com.google.firebase.database.Exclude;

import java.io.Serializable;
import java.util.Map;



    public class CustomerMeasurements implements Serializable

            //code from youtube video https://www.youtube.com/watch?v=741QCymuky4
    {
        @Exclude
        private String DressSize;
        private String Waist;
        private String Hips;
        private String Inseam;
        private String Bust;
        private String Additional;

        //empty public constructor defined to pass data from instant node of database to properties back and forth
        public CustomerMeasurements() {}


        //constructor to pass the value through
        public CustomerMeasurements(String DressSize, String Waist, String Hips, String Inseam, String Bust, String Additional) {
            this.DressSize = DressSize;
            this.Waist = Waist;
            this.Hips = Hips;
            this.Inseam = Inseam;
            this.Bust = Bust;
            this.Additional = Additional;
        }

        public String getDressSize() {
            return DressSize;
        }

        public void setDressSize(String dressSize) {
            DressSize = dressSize;
        }

        public String getWaist() {
            return Waist;
        }

        public void setWaist(String waist) {
            Waist = waist;
        }

        public String getHips() {
            return Hips;
        }

        public void setHips(String hips) {
            Hips = hips;
        }

        public String getInseam() {
            return Inseam;
        }

        public void setInseam(String inseam) {
            Inseam = inseam;
        }

        public String getBust() {
            return Bust;
        }

        public void setBust(String bust) {
            Bust = bust;
        }

        public String getAdditional() {
            return Additional;
        }

        public void setAdditional(String additional) {
            Additional = additional;
        }

    }



