package com.example.scstitch;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

//code from https://www.youtube.com/watch?v=7IJf7KeetEo&list=PLnisUReSm0-kNhfXJHymlIFeyGYHj87tP&index=20

public class EditTailorProfileActivity extends AppCompatActivity {

    //code found on youtube video https://www.youtube.com/watch?v=741QCymuky4

    private FirebaseAuth authProfile;
    private ProgressBar progressBar;
    private Button btnSaveChanges;
    private String fullName, address, proficiency, email, qualification, ratePerHour;
    private EditText etEditFullName, etEditProficiency, etEditAddress, etEditEmail, etEditRatePerHour, etEditQualification;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // connect to xml file
        setContentView(R.layout.activity_edit_tailor_profile);


        getSupportActionBar().setTitle("Edit tailor profile");

        //set which ids relate to each variable
        etEditFullName = findViewById(R.id.etEditFullName);
        etEditProficiency = findViewById(R.id.etEditProficiency);
        etEditAddress = findViewById(R.id.etEditAddress);
        etEditEmail = findViewById(R.id.etEditEmail);
        etEditRatePerHour = findViewById(R.id.etEditRatePerHour);
        etEditQualification = findViewById(R.id.etEditQualification);

        authProfile = FirebaseAuth.getInstance();
        FirebaseUser firebaseUser = authProfile.getCurrentUser();

        FirebaseUser currentFirebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        Toast.makeText(this, "" + currentFirebaseUser.getUid(), Toast.LENGTH_SHORT).show();

        //show profile data
        showProfile(firebaseUser);

        //update profile
        btnSaveChanges = findViewById(R.id.btnSaveChanges);
        btnSaveChanges.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateProfile(firebaseUser);
            }
        });
    }

    private void updateProfile(FirebaseUser firebaseUser) {
        //create database connection
        DAOTailor dao = new DAOTailor();

        FirebaseUser currentFirebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        Toast.makeText(this, "" + currentFirebaseUser.getUid(), Toast.LENGTH_SHORT).show();

        //create strings
        Tailor user = new Tailor(etEditFullName.getText().toString(), etEditAddress.getText().toString(), etEditProficiency.getText().toString(), etEditQualification.getText().toString(), etEditRatePerHour.getText().toString(), etEditEmail.getText().toString());

        String fullName = etEditFullName.getText().toString();
        String address = etEditAddress.getText().toString();
        String qualification = etEditQualification.getText().toString();
        String proficiency = etEditProficiency.getText().toString();

        dao.addUser(currentFirebaseUser.getUid(), user).addOnSuccessListener(suc ->
        {
            //if successful, bring to profile activity
            //conditions to be met in order to register user
            if (TextUtils.isEmpty(address)) {
                etEditAddress.setError("Address cannot be empty");
                etEditAddress.requestFocus();
            } else if (TextUtils.isEmpty(fullName)) {
                etEditFullName.setError("Full name cannot be empty");
                etEditFullName.requestFocus();
            } else if (TextUtils.isEmpty(proficiency)) {
                etEditProficiency.setError("PLease enter proficiency");
                etEditProficiency.requestFocus();
            } else if (TextUtils.isEmpty(qualification)) {
                etEditQualification.setError("Please enter qualification");
                etEditQualification.requestFocus();
            } else {
                Toast.makeText(EditTailorProfileActivity.this, "Changes saved successfully!", Toast.LENGTH_SHORT).show();
                //open profile activity when user registered and not let user return to registration page
                Intent intent = new Intent(EditTailorProfileActivity.this, TailorProfileActivity.class);
                intent.setFlags((intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK
                        | Intent.FLAG_ACTIVITY_NEW_TASK));
                startActivity(intent);
                finish();

            }
        });
    }


    //fetch data and set to edit text
    private void showProfile(FirebaseUser firebaseUser) {

        //progressBar.setVisibility(View.VISIBLE);
        String userID = firebaseUser.getUid();

        //extracting user reference from database
        DatabaseReference referenceProfile = FirebaseDatabase.getInstance("https://scstitch-5ae62-default-rtdb.firebaseio.com").getReference("Tailor");
        referenceProfile.child(userID).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Tailor tailor = snapshot.getValue(Tailor.class);
                if (tailor != null) {
                    fullName = tailor.getFullName();
                    address = tailor.getAddress();
                    ratePerHour = tailor.getRatePerHour();
                    proficiency = tailor.getProficiency();
                    qualification = tailor.getQualification();
                    email = tailor.getEmail();

                    etEditFullName.setText(fullName);
                    etEditAddress.setText(address);
                    etEditQualification.setText(qualification);
                    etEditProficiency.setText(proficiency);
                    etEditRatePerHour.setText(ratePerHour);
                    etEditEmail.setText(email);

                } else {
                    Toast.makeText(EditTailorProfileActivity.this, "Something went wrong", Toast.LENGTH_SHORT).show();
                }
//                    progressBar.setVisibility(View.GONE);
            }


            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(EditTailorProfileActivity.this, "Something went wrong", Toast.LENGTH_SHORT).show();
                //progressBar.setVisibility(View.GONE);
            }
        });
    }
}
