package com.example.scstitch;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class OrderSummaryActivity extends AppCompatActivity {

    //all code from https://www.youtube.com/watch?v=MnJg1f25h_g&list=PLnisUReSm0-kNhfXJHymlIFeyGYHj87tP&index=14

    private ImageView imageViewOrder;
    private ArrayList<Model> list;

    private StorageReference storageReference;
    private TextView tvOrderType, tvDetails, tvItem, tvPostageAddress;
    private ProgressBar progressBar;
    private String orderType, details, item, postageAddress;
    private FirebaseAuth authProfile;
    private Button btnFindTailor;
    private MyAdapter adapter;

    private DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Orders");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_summary);

        getSupportActionBar().setTitle("Order summary");

        authProfile = FirebaseAuth.getInstance();
        FirebaseUser firebaseUser = authProfile.getCurrentUser();

        btnFindTailor = findViewById(R.id.btnFindTailor);

//        root.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
//                    Model model = dataSnapshot.getValue(Model.class);
//                    list.add(model);
//                }
//                adapter.notifyDataSetChanged();
//            }

//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//            }
//        });

        tvOrderType = findViewById(R.id.tvOrderType);
        tvDetails = findViewById(R.id.tvDetails);
        tvItem = findViewById(R.id.tvItem);
        tvPostageAddress = findViewById(R.id.tvPostageAddress);
        progressBar = findViewById(R.id.progressBar);
        imageViewOrder = findViewById(R.id.imageViewOrder);


        if (firebaseUser == null) {
            Toast.makeText(OrderSummaryActivity.this, "Error occurred, order details unattainable at this moment", Toast.LENGTH_LONG).show();
        } else {
//            progressBar.setVisibility(View.VISIBLE);
            showOrder(firebaseUser);
        }
    }

    private void showOrder(FirebaseUser firebaseUser) {
        progressBar.setVisibility(View.VISIBLE);
        String userID = firebaseUser.getUid();

        //extracting user reference from database
        DatabaseReference referenceProfile = FirebaseDatabase.getInstance("https://scstitch-5ae62-default-rtdb.firebaseio.com").getReference("Orders");

        referenceProfile.child(userID).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                Orders order = snapshot.getValue(Orders.class);
                if (order != null) {
                    orderType = order.getOrderType();
                    item = order.getItem();
                    details = order.getDetails();
                    postageAddress = order.getPostageAddress();

                    progressBar.setVisibility(View.INVISIBLE);

                    tvOrderType.setText(orderType);
                    tvItem.setText(item);
                    tvDetails.setText(details);
                    tvPostageAddress.setText(postageAddress);

                    StorageReference storageReference = FirebaseStorage.getInstance().getReference("Orders/" + userID + ".jpg");

                        //code from https://www.youtube.com/watch?v=DRqObCUCGl0

                    try {
                        File localFile = File.createTempFile("tempFile", ".jpg");
                        storageReference.getFile(localFile)
                                .addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
                                    @Override
                                    public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {

                                        Bitmap bitmap = BitmapFactory.decodeFile(localFile.getAbsolutePath());
                                        imageViewOrder.setImageBitmap(bitmap);

                                    }
                                }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(OrderSummaryActivity.this, "Something went wrong", Toast.LENGTH_SHORT).show();

                            }
                        });
                    } catch (IOException e) {
                        e.printStackTrace();
                    }


                } else {
                    Toast.makeText(OrderSummaryActivity.this, "Something went wrong", Toast.LENGTH_LONG).show();

                }
            }

            //triggered in event of failure due to firebase rules
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(OrderSummaryActivity.this, "Something went wrong", Toast.LENGTH_LONG).show();
            }

        });

        //bring user to select tailor activity
        btnFindTailor.setOnClickListener(view ->{
            startActivity(new Intent(OrderSummaryActivity.this, ViewTailorsActivity.class));
        });

    }
    //create action bar menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //inflate menu items
        getMenuInflater().inflate(R.menu.order_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    //when any menu item selected
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item){
        int id = item.getItemId();

        if (id == R.id.menu_refresh){
            //refresh
            startActivity(getIntent());
            finish();
            overridePendingTransition(0, 0);
        } else if (id == R.id.menu_profile){
            Intent intent = new Intent(OrderSummaryActivity.this, CustomerProfileActivity.class);
            startActivity(intent);
        } else if (id == R.id.menu_measurements){
            Intent intent = new Intent(OrderSummaryActivity.this, CustomerMeasurementsActivity.class);
            startActivity(intent);
        }else if (id == R.id.menu_logout) {
            authProfile.signOut();
            Toast.makeText(OrderSummaryActivity.this, "Signed out", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(OrderSummaryActivity.this, HomeActivity.class);
            startActivity(intent);
            finish(); // close user profile activity
        }else {
            Toast.makeText(OrderSummaryActivity.this, "Something went wrong", Toast.LENGTH_LONG).show();
        }
        return super.onOptionsItemSelected(item);
    }
}


