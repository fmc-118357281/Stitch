package com.example.scstitch;

import com.google.firebase.database.Exclude;

import java.io.Serializable;

public class OrderForTailor
        //code from youtube video https://www.youtube.com/watch?v=741QCymuky4
{
    public String getOrderImage() {
        return OrderImage;
    }

    public void setOrderImage(String orderImage) {
        OrderImage = orderImage;
    }

    private String OrderImage;
    private String Item;
    private String Details;
    private String OrderType;
    private String PostageAddress;
    private String CustName;


    //empty public constructor defined to pass data from instant node of database to properties back and forth
    public OrderForTailor() {}

    public String getPostageAddress() {
        return PostageAddress;
    }

    public void setPostageAddress(String postageAddress) {
        PostageAddress = postageAddress;
    }


    public String getCustName() {
        return CustName;
    }

    public void setCustName(String custName) {
        CustName = custName;
    }


    //getters and setters
    public String getItem() {
        return Item;
    }

    public void setItem(String item) {
        Item = item;
    }

    public String getDetails() {
        return Details;
    }

    public void setDetails(String details) {
        Details = details;
    }

    public String getOrderType() {
        return OrderType;
    }

    public void setOrderType(String orderType) {
        OrderType = orderType;
    }

    //constructor to pass the value through
    public OrderForTailor(String Details, String Item, String OrderType, String CustName, String PostageAddress, String OrderImage) {
        this.Details = Item;
        this.Item = Details;
        this.OrderType = OrderType;
        this.PostageAddress = PostageAddress;
        this.CustName = CustName;
        this.OrderImage = OrderImage;

    }
}


