package com.example.scstitch;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

public class CustomerFinalActivity extends AppCompatActivity {

    private FirebaseAuth authProfile;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_final);

        getSupportActionBar().setTitle("Thank you!");

    }

    //create action bar menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //inflate menu items
        getMenuInflater().inflate(R.menu.customer_view_tailors, menu);
        return super.onCreateOptionsMenu(menu);
    }

    //when any menu item selected
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.menu_refresh) {
            //refresh
            startActivity(getIntent());
            finish();
            overridePendingTransition(0, 0);
        } else if (id == R.id.menu_profile) {
            Intent intent = new Intent(CustomerFinalActivity.this, CustomerProfileActivity.class);
            startActivity(intent);
        } else if (id == R.id.menu_orders) {
            Intent intent = new Intent(CustomerFinalActivity.this, OrderSummaryActivity.class);
            startActivity(intent);
        } else if (id == R.id.menu_measurements) {
            Intent intent = new Intent(CustomerFinalActivity.this, CustomerMeasurementsActivity.class);
            startActivity(intent);
        } else if (id == R.id.menu_logout) {
            authProfile.signOut();
            Toast.makeText(CustomerFinalActivity.this, "Signed out", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(CustomerFinalActivity.this, HomeActivity.class);
            startActivity(intent);
            finish(); // close user profile activity
        } else {
            Toast.makeText(CustomerFinalActivity.this, "Something went wrong", Toast.LENGTH_LONG).show();
        }
        return super.onOptionsItemSelected(item);
    }
}