package com.example.scstitch;

import android.widget.ImageView;

import com.google.firebase.database.Exclude;

import java.io.Serializable;

public class Orders implements Serializable  {

    //code from youtube video https://www.youtube.com/watch?v=741QCymuky4

    //declaring strings
        @Exclude
        private String Item;
        private String Details;
        private String OrderType;

    public String getPostageAddress() {
        return PostageAddress;
    }

    public void setPostageAddress(String postageAddress) {
        PostageAddress = postageAddress;
    }

    private String PostageAddress;

        //empty public constructor defined to pass data from instant node of database to properties back and forth
        public Orders() {}

//getters and setters
    public String getItem() {
        return Item;
    }

    public void setItem(String item) {
        Item = item;
    }

    public String getDetails() {
        return Details;
    }

    public void setDetails(String details) {
        Details = details;
    }

    public String getOrderType() {
        return OrderType;
    }

    public void setOrderType(String orderType) {
        OrderType = orderType;
    }

    //constructor to pass the value through
    public Orders(String Details, String Item, String OrderType, String PostageAddress) {
        this.Details = Item;
        this.Item = Details;
        this.OrderType = OrderType;
        this.PostageAddress = PostageAddress;

    }
}
