package com.example.scstitch;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

public class CreateOrderActivity extends AppCompatActivity {

    //code found on youtube video https://www.youtube.com/watch?v=741QCymuky4


    RadioGroup radioGpOrderType;
    RadioButton radioBtnSubmitTypeSelected;
    EditText etItem, etDetails, etPostageAddress;
    Button btnSubmitOrder;
    private Button uploadBtn;
    private ImageView imageView;
    private FirebaseAuth authProfile;
    FirebaseUser firebaseUser;
    ProgressBar progressBar;
    private String OrderTypeRadio;
    StorageReference fileReference;
    private Uri imageUri;
    DatabaseReference root;

    //vars
    StorageReference reference = FirebaseStorage.getInstance().getReference("Orders");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FirebaseUser currentFirebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        Toast.makeText(this, "" + currentFirebaseUser.getUid(), Toast.LENGTH_SHORT).show();

        setContentView(R.layout.activity_create_order);

        authProfile = FirebaseAuth.getInstance();
        FirebaseUser firebaseUser = authProfile.getCurrentUser();

        //create database connection
        DAOOrders dao = new DAOOrders();

        getSupportActionBar().setTitle("Create order");

        //link to UI elements
        imageView = findViewById(R.id.imageView);
        btnSubmitOrder = findViewById(R.id.btnSubmitOrder);
        etDetails = findViewById(R.id.etDetails);
        etItem = findViewById(R.id.etItem);
        etPostageAddress = findViewById(R.id.etPostageAddress);
        progressBar = findViewById(R.id.progressBar);
        uploadBtn = findViewById(R.id.upload_btn);
        radioGpOrderType = findViewById(R.id.radioGpOrderType);
        radioGpOrderType.clearCheck();

        progressBar.setVisibility(View.INVISIBLE);

        //code from https://www.youtube.com/watch?fbclid=IwAR1MRA1FYn_OtAjS4eBugjW5J9Fn5Ba1j_xMJPIHUKoBkNvHiSa4GYwaJw8&v=9-oa4OS7lUQ&feature=youtu.be

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent galleryIntent = new Intent();
                galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
                galleryIntent.setType("image/*");
                startActivityForResult(galleryIntent, 2);
            }
        });

        uploadBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (imageUri != null) {
                     uploadToFirebase(imageUri);
                    progressBar.setVisibility(View.VISIBLE);
                } else {
                    Toast.makeText(CreateOrderActivity.this, "Please Select Image", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnSubmitOrder.setOnClickListener(v ->
        {

            if (radioGpOrderType.getCheckedRadioButtonId() == -1) {
                Toast.makeText(getApplicationContext(), "Please select order type", Toast.LENGTH_SHORT).show();
            } else {
                // get selected radio button from radioGroup
                int selectedOrderId = radioGpOrderType.getCheckedRadioButtonId();
                // find the radiobutton by returned id
                radioBtnSubmitTypeSelected = findViewById(selectedOrderId);
                //save to DB
                OrderTypeRadio = radioBtnSubmitTypeSelected.getText().toString();

                Orders order = new Orders(etItem.getText().toString(), etDetails.getText().toString(), OrderTypeRadio, etPostageAddress.getText().toString());

                String item = etItem.getText().toString();
                String details = etDetails.getText().toString();
                String postageAddress = etPostageAddress.getText().toString();

                dao.addOrder(currentFirebaseUser.getUid(), order).addOnSuccessListener(suc ->
                {
                    //if successful, bring to profile activity
                    //conditions to be met in order to register user
                    if (TextUtils.isEmpty(item)) {
                        etItem.setError("Item of clothing cannot be empty");
                        etItem.requestFocus();
                    } else if (TextUtils.isEmpty(details)) {
                        etItem.setError("Details cannot be empty");
                        etItem.requestFocus();
                    } else if (TextUtils.isEmpty(postageAddress)) {
                        etItem.setError("Postage address cannot be empty");
                        etItem.requestFocus();
                    } else {
                        progressBar.setVisibility(View.VISIBLE);
                        Toast.makeText(CreateOrderActivity.this, "Order submitted successfully!", Toast.LENGTH_LONG).show();
                        // bring user to profile page
                        // prevent user from returning back to create profile activity once registration successful
                        Intent intent = new Intent(CreateOrderActivity.this, OrderSummaryActivity.class);
                        intent.setFlags((intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK
                                | Intent.FLAG_ACTIVITY_NEW_TASK));
                        startActivity(intent);
                        finish();
                    }
                }).addOnFailureListener(er ->
                {
                    Toast.makeText(CreateOrderActivity.this, "Error occured", Toast.LENGTH_LONG).show();
                });
                progressBar.setVisibility(View.GONE);
            }

        });



    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 2 && resultCode == RESULT_OK && data != null) {

            imageUri = data.getData();
            imageView.setImageURI(imageUri);
        }
    }

    //upload image code https://www.youtube.com/watch?fbclid=IwAR3CEJni2TvxGvR4nwWraA788-EblZkqSN7ZIYxKrZu2ofGnkfYq4pp628A&v=9-oa4OS7lUQ&feature=youtu.be
    private void uploadToFirebase(Uri uri) {
        if (imageUri != null) {

            //get current user
            String userUid = FirebaseAuth.getInstance().getCurrentUser().getUid();

            //save image with uid of current user
             fileReference = reference.child(userUid + "." + getFileExtension(uri));


            //fileReference = FirebaseStorage.getInstance().getReference().child(userUid);

            //save image to realtime path orders as child of user id
            DatabaseReference root = FirebaseDatabase.getInstance().getReference("Orders").child(userUid);

             //upload image to storage
            fileReference.putFile(imageUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    fileReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(Uri uri) {

                            Model model = new Model(uri.toString());
                            String modelId = root.push().getKey();
                            root.child(modelId).setValue(model);
                            Toast.makeText(CreateOrderActivity.this, "Image uploaded successfully", Toast.LENGTH_SHORT).show();

                        }
                    });

                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(CreateOrderActivity.this, "Image uploaded successfully", Toast.LENGTH_SHORT).show();
                }

            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(CreateOrderActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            progressBar.setVisibility(View.GONE);
            Toast.makeText(CreateOrderActivity.this, "No file selected", Toast.LENGTH_SHORT).show();
        }
    }

    private String getFileExtension(Uri mUri) {

        ContentResolver cr = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cr.getType(mUri));

    }


    //create action bar menu
    //code from https://www.youtube.com/watch?v=ElJ8AGIJfDE&list=PLnisUReSm0-kNhfXJHymlIFeyGYHj87tP&index=15
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //inflate menu items
        getMenuInflater().inflate(R.menu.order_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    //when any menu item selected
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item){
        int id = item.getItemId();

        if (id == R.id.menu_refresh){
            //refresh
            startActivity(getIntent());
            finish();
            overridePendingTransition(0, 0);
        } else if (id == R.id.menu_profile){
            Intent intent = new Intent(CreateOrderActivity.this, CustomerProfileActivity.class);
            startActivity(intent);
        } else if (id == R.id.menu_measurements){
            Intent intent = new Intent(CreateOrderActivity.this, CustomerMeasurementsActivity.class);
            startActivity(intent);
        }else if (id == R.id.menu_logout) {
            authProfile.signOut();
            Toast.makeText(CreateOrderActivity.this, "Signed out", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(CreateOrderActivity.this, HomeActivity.class);
            startActivity(intent);
            finish(); // close user profile activity
        }else {
            Toast.makeText(CreateOrderActivity.this, "Something went wrong", Toast.LENGTH_LONG).show();
        }
        return super.onOptionsItemSelected(item);
    }
}








