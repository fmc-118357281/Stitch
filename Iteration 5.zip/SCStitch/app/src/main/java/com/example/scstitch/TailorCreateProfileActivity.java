package com.example.scstitch;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;



public class TailorCreateProfileActivity extends AppCompatActivity {

    //code found on youtube video https://www.youtube.com/watch?v=741QCymuky4


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        FirebaseUser currentFirebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        Toast.makeText(this, "" + currentFirebaseUser.getUid(), Toast.LENGTH_SHORT).show();

        // connect to xml file
        setContentView(R.layout.activity_create_profile_tailor);

        //create profile button functionality
        Button btnCreateProfile = findViewById(R.id.btnCreateProfile);

        //create database connection
        DAOTailor dao = new DAOTailor();

        getSupportActionBar().setTitle("Tailor profile");

        //set which ids relate to each variable
        final EditText etRegFullName = findViewById(R.id.etRegFullName);
        final EditText etRegProficiency = findViewById(R.id.etRegProficiency);
        final EditText etRegAddress = findViewById(R.id.etRegAddress);
        final EditText etRegEmail = findViewById(R.id.etRegEmail);
        final EditText etRegRatePerHour = findViewById(R.id.etRegRatePerHour);
        final EditText etRegQualification = findViewById(R.id.etRegQualification);
        final ProgressBar progressBar = findViewById(R.id.progressBar);

        btnCreateProfile.setOnClickListener(v ->
        {
            //connect to db
            Tailor user = new Tailor(etRegFullName.getText().toString(), etRegAddress.getText().toString(), etRegEmail.getText().toString(), etRegProficiency.getText().toString(), etRegRatePerHour.getText().toString(), etRegQualification.getText().toString());

            //create strings
             String fullName = etRegFullName.getText().toString();
             String email = etRegEmail.getText().toString();
             String address = etRegAddress.getText().toString();
             String qualification = etRegQualification.getText().toString();
             String ratePerHour = etRegRatePerHour.getText().toString();
             String proficiency = etRegProficiency.getText().toString();

            dao.addUser(currentFirebaseUser.getUid(), user).addOnSuccessListener(suc ->
            {
                //conditions to be met in order to register user
                if (TextUtils.isEmpty(email)) {
                    etRegEmail.setError("Work email cannot be empty");
                    etRegEmail.requestFocus();
                } else if (TextUtils.isEmpty(qualification)) {
                    etRegQualification.setError("Qualification cannot be empty");
                    etRegQualification.requestFocus();
                } else if (TextUtils.isEmpty(proficiency)) {
                    etRegProficiency.setError("Proficiency cannot be empty");
                    etRegProficiency.requestFocus();
                } else if (TextUtils.isEmpty(address)) {
                    etRegAddress.setError("Address cannot be empty");
                    etRegAddress.requestFocus();
                } else if (TextUtils.isEmpty(fullName)) {
                    etRegFullName.setError("Full name cannot be empty");
                    etRegFullName.requestFocus();
                } else if (TextUtils.isEmpty(ratePerHour)) {
                    etRegRatePerHour.setError("Rate per hour cannot be empty");
                    etRegRatePerHour.requestFocus();
                } else {
                    progressBar.setVisibility(View.VISIBLE);
                    Toast.makeText(this, "Your tailor profile has been created", Toast.LENGTH_SHORT).show();
                    // bring user to profile page
                    // prevent user from returning back to create profile activity once registration successful
                    Intent intent = new Intent(TailorCreateProfileActivity.this, TailorProfileActivity.class);
                    intent.setFlags((intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK
                            | Intent.FLAG_ACTIVITY_NEW_TASK));
                    startActivity(intent);
                    finish();
                }
            }).addOnFailureListener(er ->
            {
                Toast.makeText(this, "" + er.getMessage(), Toast.LENGTH_SHORT).show();
            });
            progressBar.setVisibility(View.GONE);

        });
    }
}