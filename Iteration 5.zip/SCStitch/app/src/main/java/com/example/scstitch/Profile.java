package com.example.scstitch;

public class Profile
        //code from youtube video https://www.youtube.com/watch?v=741QCymuky4
{
    private String FullName;
    private String Email;
    private String ProfilePic;
    private String Proficiency;
    private String Address;

    //empty public constructor defined to pass data from instant node of database to properties back and forth
    public Profile() {}

    //constructor to pass the value through
    public Profile(String FullName, String ProfilePic, String Email, String Proficiency, String Address) {
        this.FullName = FullName;
        this.Email = Email;
        this.ProfilePic = ProfilePic;
        this.Proficiency = Proficiency;
        this.Address = Address;
    }

    public String getFullName() {
        return FullName;
    }

    public void setFullName(String fullName) {
        FullName = fullName;
    }


    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }


    public String getProficiency() {
        return Proficiency;
    }

    public void setProficiency(String proficiency) {
        Proficiency = proficiency;
    }

    public String getProfilePic() {
        return ProfilePic;
    }

    public void setProfilePic(String profilePic) {
        ProfilePic = ProfilePic;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

}



