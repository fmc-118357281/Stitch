package com.example.scstitch;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class TailorViewOrdersActivity extends AppCompatActivity {
    FirebaseAuth authProfile;
    DatabaseReference reference;
    RecyclerView recyclerView;
    ArrayList<OrderForTailor> list;
    OrderAdapter adapter;
    Button btnViewMeasurements;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tailor_view_orders);

        getSupportActionBar().setTitle("Your orders");

        authProfile = FirebaseAuth.getInstance();
        FirebaseUser firebaseUser = authProfile.getCurrentUser();

        btnViewMeasurements = findViewById(R.id.btnViewMeasurements);

        recyclerView = (RecyclerView) findViewById(R.id.orderRecycler);
        recyclerView.setLayoutManager( new LinearLayoutManager(this));
        list = new ArrayList<OrderForTailor>();

        reference = FirebaseDatabase.getInstance().getReference("Orders");

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {

                    OrderForTailor p = dataSnapshot1.getValue(OrderForTailor.class);
                    list.add(p);
                }
                adapter = new OrderAdapter(TailorViewOrdersActivity.this,list);
                recyclerView.setAdapter(adapter);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(TailorViewOrdersActivity.this, "Something went wrong", Toast.LENGTH_SHORT).show();

            }
        });

        //view measurements button functionality
        btnViewMeasurements.setOnClickListener(view -> {
            startActivity(new Intent(TailorViewOrdersActivity.this, TailorViewMeasurementsActivity.class));
        });

    }

    //create action bar menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //inflate menu items
        getMenuInflater().inflate(R.menu.tailor_orders, menu);
        return super.onCreateOptionsMenu(menu);
    }

    //when any menu item selected
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item){
        int id = item.getItemId();

        if (id == R.id.menu_refresh){
            //refresh
            startActivity(getIntent());
            finish();
            overridePendingTransition(0, 0);
        } else if (id == R.id.menu_profile){
            Intent intent = new Intent(TailorViewOrdersActivity.this, TailorProfileActivity.class);
            startActivity(intent);
        }else if (id == R.id.menu_logout) {
            authProfile.signOut();
            Toast.makeText(TailorViewOrdersActivity.this, "Signed out", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(TailorViewOrdersActivity.this, HomeActivity.class);
            startActivity(intent);
            finish(); // close user profile activity
        }else {
            Toast.makeText(TailorViewOrdersActivity.this, "Something went wrong", Toast.LENGTH_LONG).show();
        }
        return super.onOptionsItemSelected(item);
    }
}