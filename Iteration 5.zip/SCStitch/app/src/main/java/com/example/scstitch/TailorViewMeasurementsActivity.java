package com.example.scstitch;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class TailorViewMeasurementsActivity extends AppCompatActivity {

    FirebaseAuth authProfile;
    DatabaseReference reference;
    RecyclerView recyclerView;
    ArrayList<CustomerMeasurements> list;
    MeasurementsAdapter adapter;
    Button btnViewOrders;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tailor_view_measurements);

        getSupportActionBar().setTitle("Your customer's measurements");

        authProfile = FirebaseAuth.getInstance();
        FirebaseUser firebaseUser = authProfile.getCurrentUser();

        recyclerView = (RecyclerView) findViewById(R.id.measurementsRecycler);
        recyclerView.setLayoutManager( new LinearLayoutManager(this));
        list = new ArrayList<CustomerMeasurements>();

        btnViewOrders = findViewById(R.id.btnViewOrders);

        reference = FirebaseDatabase.getInstance().getReference("Customer");


        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {

                   for (DataSnapshot messageSnapshot: dataSnapshot1.child("measurements").getChildren());

                        CustomerMeasurements p = dataSnapshot1.getValue(CustomerMeasurements.class);
                        list.add(p);
                }
                adapter = new MeasurementsAdapter(TailorViewMeasurementsActivity.this,list);
                recyclerView.setAdapter(adapter);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(TailorViewMeasurementsActivity.this, "Something went wrong", Toast.LENGTH_SHORT).show();

            }

        });

        //view measurements button functionality
        btnViewOrders.setOnClickListener(view -> {
            startActivity(new Intent(TailorViewMeasurementsActivity.this, TailorViewOrdersActivity.class));
        });
    }


    //create action bar menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //inflate menu items
        getMenuInflater().inflate(R.menu.tailor_orders, menu);
        return super.onCreateOptionsMenu(menu);
    }

    //when any menu item selected
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item){
        int id = item.getItemId();

        if (id == R.id.menu_refresh){
            //refresh
            startActivity(getIntent());
            finish();
            overridePendingTransition(0, 0);
        } else if (id == R.id.menu_profile){
            Intent intent = new Intent(TailorViewMeasurementsActivity.this, TailorProfileActivity.class);
            startActivity(intent);
        }else if (id == R.id.menu_logout) {
            authProfile.signOut();
            Toast.makeText(TailorViewMeasurementsActivity.this, "Signed out", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(TailorViewMeasurementsActivity.this, HomeActivity.class);
            startActivity(intent);
            finish(); // close user profile activity
        }else {
            Toast.makeText(TailorViewMeasurementsActivity.this, "Something went wrong", Toast.LENGTH_LONG).show();
        }
        return super.onOptionsItemSelected(item);
    }
}