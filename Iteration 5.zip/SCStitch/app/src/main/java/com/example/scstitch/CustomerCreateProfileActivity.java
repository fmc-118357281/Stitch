package com.example.scstitch;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.Calendar;


public class CustomerCreateProfileActivity extends AppCompatActivity {

    //code found on youtube video https://www.youtube.com/watch?v=741QCymuky4

    RadioButton radioBtnSubmitGenderSelected;
    private DatePickerDialog picker;
    private String GenderRadio;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        FirebaseUser currentFirebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        Toast.makeText(this, "" + currentFirebaseUser.getUid(), Toast.LENGTH_SHORT).show();

        // connect to xml file
        setContentView(R.layout.activity_create_profile_customer);

        //create profile button functionality
        Button btnCreateProfile = findViewById(R.id.btnCreateProfile);

        //create database connection
        DAOCustomer dao = new DAOCustomer();

        getSupportActionBar().setTitle("Customer profile");

        //set which ids relate to each variable
        final EditText etRegFullName = findViewById(R.id.etRegFullName);
        final EditText etRegDOB = findViewById(R.id.etRegDOB);
        final EditText etRegAddress = findViewById(R.id.etRegAddress);
        final EditText etRegPhone = findViewById(R.id.etRegPhone);
        final ProgressBar progressBar = findViewById(R.id.progressBar);
        final RadioGroup radioGpGender = findViewById(R.id.radioGpGender);
        radioGpGender.clearCheck();


        //setting date picker for edit text
        etRegDOB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar calendar = Calendar.getInstance();
                int day = calendar.get(Calendar.DAY_OF_MONTH);
                int month = calendar.get(Calendar.MONTH);
                int year = calendar.get(Calendar.YEAR);

                //date picker dialog
                picker = new DatePickerDialog(CustomerCreateProfileActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        etRegDOB.setText(dayOfMonth + "/" + (month + 1) + "/" + year);
                    }
                }, year, month, day);
                picker.show();
            }
        });


        btnCreateProfile.setOnClickListener(v ->
        {

            if (radioGpGender.getCheckedRadioButtonId() == -1) {
                Toast.makeText(getApplicationContext(), "Please select Gender", Toast.LENGTH_SHORT).show();
            } else {
                // get selected radio button from radioGroup
                int selectedOrderId = radioGpGender.getCheckedRadioButtonId();
                // find the radiobutton by returned id
                radioBtnSubmitGenderSelected = findViewById(selectedOrderId);
                //save to DB
                GenderRadio = radioBtnSubmitGenderSelected.getText().toString();

                //create strings
                Customer user1 = new Customer(etRegFullName.getText().toString(), etRegDOB.getText().toString(), etRegAddress.getText().toString(), etRegPhone.getText().toString(), GenderRadio);

                String fullName = etRegFullName.getText().toString();
                String address = etRegAddress.getText().toString();

                dao.addUser(currentFirebaseUser.getUid(), user1).addOnSuccessListener(suc ->
                {
                    //if successful, bring to profile activity
                    //conditions to be met in order to register user
                    if (etRegPhone.length() != 10) {
                        etRegPhone.setError("Phone number should be 10 digits");
                        etRegPhone.requestFocus();
                    } else if (TextUtils.isEmpty(address)) {
                        etRegAddress.setError("Email cannot be empty");
                        etRegAddress.requestFocus();
                    } else if (TextUtils.isEmpty(fullName)) {
                        etRegFullName.setError("Full name cannot be empty");
                        etRegFullName.requestFocus();
                    } else {
                        progressBar.setVisibility(View.VISIBLE);
                        Toast.makeText(this, "Your customer profile has been created", Toast.LENGTH_SHORT).show();
                        // bring user to profile page
                        // prevent user from returning back to create profile activity once registration successful
                        Intent intent = new Intent(CustomerCreateProfileActivity.this, CustomerAddMeasurementsActivity.class);
                        intent.setFlags((intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK
                                | Intent.FLAG_ACTIVITY_NEW_TASK));
                        startActivity(intent);
                        finish();
                    }
                }).addOnFailureListener(er ->
                {
                    Toast.makeText(this, "" + er.getMessage(), Toast.LENGTH_SHORT).show();
                });
                progressBar.setVisibility(View.GONE);


            }
        });
    }
}

