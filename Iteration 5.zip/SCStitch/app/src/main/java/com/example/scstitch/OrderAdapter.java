package com.example.scstitch;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.MyViewHolder> {
    Context context;
    ArrayList<OrderForTailor> orderForTailor;

    public OrderAdapter(Context c, ArrayList<OrderForTailor> p){
        orderForTailor = p;
        context = c;
    }

    @NonNull
    @Override
    public OrderAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new OrderAdapter.MyViewHolder(LayoutInflater.from(context).inflate(R.layout.order_info,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull OrderAdapter.MyViewHolder holder, int position) {

        //connect to ui
        holder.tvPostageAddress.setText(orderForTailor.get(position).getPostageAddress());
        holder.tvOrderType.setText(orderForTailor.get(position).getOrderType());
        holder.tvItem.setText(orderForTailor.get(position).getItem());
        holder.tvDetails.setText(orderForTailor.get(position).getDetails());
        Picasso.with(context).load(orderForTailor.get(position).getOrderImage()).into(holder.orderImage);

    }

    @Override
    public int getItemCount() {
        return orderForTailor.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder{

        //declare vars
        TextView  tvPostageAddress, tvOrderType, tvItem, tvDetails;
        ImageView orderImage;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
           tvPostageAddress = (TextView) itemView.findViewById(R.id.tvPostageAddress);
            tvOrderType = (TextView) itemView.findViewById(R.id.tvOrderType);
            tvItem = (TextView) itemView.findViewById(R.id.tvItem);
            tvDetails = (TextView) itemView.findViewById(R.id.tvDetails);
            orderImage = (ImageView) itemView.findViewById(R.id.orderImage);
        }


        }
    }



