package com.example.scstitch;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

//code from https://www.youtube.com/watch?v=7IJf7KeetEo&list=PLnisUReSm0-kNhfXJHymlIFeyGYHj87tP&index=20
public class EditCustomerProfileActivity extends AppCompatActivity {

    private TextView tvGender;
    private EditText etEditFullName, etEditAddress, etEditDOB, etEditPhone;
    private ProgressBar progressBar;
    private String fullName, address, dob, phone, gender;
    private FirebaseAuth authProfile;
    private Button btnSaveChanges;
    private RadioButton radioBtnEditGenderSelected;
    private RadioGroup radioGroupEditGender;
    private String GenderRadio;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_customer_profile);


        getSupportActionBar().setTitle("Edit customer profile");

        progressBar = findViewById(R.id.progressBar);

        etEditFullName = findViewById(R.id.etEditFullName);
        etEditAddress = findViewById(R.id.etEditAddress);
        etEditDOB = findViewById(R.id.etEditDOB);
        etEditPhone = findViewById(R.id.etEditPhone);

        radioGroupEditGender = findViewById(R.id.radioGroupEditGender);

        authProfile = FirebaseAuth.getInstance();
        FirebaseUser firebaseUser = authProfile.getCurrentUser();

        FirebaseUser currentFirebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        Toast.makeText(this, "" + currentFirebaseUser.getUid(), Toast.LENGTH_SHORT).show();

        //show profile data
        showProfile(firebaseUser);


        //update profile
        btnSaveChanges = findViewById(R.id.btnSaveChanges);
        btnSaveChanges.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateProfile(firebaseUser);
            }
        });
    }

    private void updateProfile(FirebaseUser firebaseUser) {
        //create database connection
        DAOCustomer dao = new DAOCustomer();

        FirebaseUser currentFirebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        Toast.makeText(this, "" + currentFirebaseUser.getUid(), Toast.LENGTH_SHORT).show();


        // get selected radio button from radioGroup
        int selectedOrderId = radioGroupEditGender.getCheckedRadioButtonId();
        // find the radiobutton by returned id
        radioBtnEditGenderSelected = findViewById(selectedOrderId);
        //save to DB
        GenderRadio = radioBtnEditGenderSelected.getText().toString();

        //create strings
        Customer user1 = new Customer(etEditFullName.getText().toString(), etEditDOB.getText().toString(), etEditAddress.getText().toString(), etEditPhone.getText().toString(), GenderRadio);

        String fullName = etEditFullName.getText().toString();
        String address = etEditAddress.getText().toString();

        dao.addUser(currentFirebaseUser.getUid(), user1).addOnSuccessListener(suc ->
        {
            //if successful, bring to profile activity
            //conditions to be met in order to register user
            if (etEditPhone.length() != 10) {
                etEditPhone.setError("Phone number should be 10 digits");
                etEditPhone.requestFocus();
            } else if (TextUtils.isEmpty(address)) {
                etEditAddress.setError("Address cannot be empty");
                etEditAddress.requestFocus();
            } else if (TextUtils.isEmpty(radioBtnEditGenderSelected.getText())) {
                radioBtnEditGenderSelected.setError("Gender is required");
                radioBtnEditGenderSelected.requestFocus();
            } else if (TextUtils.isEmpty(fullName)) {
                etEditFullName.setError("Full name cannot be empty");
                etEditFullName.requestFocus();
            } else {
                Toast.makeText(EditCustomerProfileActivity.this, "Changes saved successfully!", Toast.LENGTH_SHORT).show();
                //open profile activity when user registered and not let user return to registration page
                Intent intent = new Intent(EditCustomerProfileActivity.this, CustomerProfileActivity.class);
                intent.setFlags((intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK
                        | Intent.FLAG_ACTIVITY_NEW_TASK));
                startActivity(intent);
                finish();

        }
        });
    }


    //fetch data and set to edit text
    private void showProfile(FirebaseUser firebaseUser) {

        progressBar.setVisibility(View.VISIBLE);
        String userID = firebaseUser.getUid();

        //extracting user reference from database
        DatabaseReference referenceProfile = FirebaseDatabase.getInstance("https://scstitch-5ae62-default-rtdb.firebaseio.com").getReference("Customer");
        referenceProfile.child(userID).child("Customer information").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Customer customer = snapshot.getValue(Customer.class);
                if (customer != null) {
                        fullName = customer.getFullName();
                        gender = customer.getGender();
                        dob = customer.getDOB();
                        phone = customer.getPhone();
                        address = customer.getAddress();

                        etEditAddress.setText(address);
                        etEditFullName.setText(fullName);
                        etEditDOB.setText(dob);
                        etEditPhone.setText(phone);

                        //show gender through radio button
                        if(gender.equals("Male")) {
                            radioBtnEditGenderSelected = findViewById(R.id.radioBtnMale);
                        } else if (gender.equals("Female")) {
                            radioBtnEditGenderSelected = findViewById(R.id.radioBtnFemale);
                        } else {radioBtnEditGenderSelected = findViewById(R.id.radioBtnOther);
                        }
                            radioBtnEditGenderSelected.setChecked(true);
                    } else {
                        Toast.makeText(EditCustomerProfileActivity.this, "Something went wrong", Toast.LENGTH_SHORT).show();
                    }
                progressBar.setVisibility(View.GONE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(EditCustomerProfileActivity.this, "Something went wrong", Toast.LENGTH_SHORT).show();
                progressBar.setVisibility(View.GONE);
            }
        });


    }

    //create action bar menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //inflate menu items
        getMenuInflater().inflate(R.menu.order_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    //when any menu item selected
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item){
        int id = item.getItemId();

        if (id == R.id.menu_refresh){
            //refresh
            startActivity(getIntent());
            finish();
            overridePendingTransition(0, 0);
        } else if (id == R.id.menu_profile){
            Intent intent = new Intent(EditCustomerProfileActivity.this, CustomerProfileActivity.class);
            startActivity(intent);
        }else if (id == R.id.menu_logout) {
            authProfile.signOut();
            Toast.makeText(EditCustomerProfileActivity.this, "Signed out", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(EditCustomerProfileActivity.this, HomeActivity.class);
            startActivity(intent);
            finish(); // close user profile activity
        }else {
            Toast.makeText(EditCustomerProfileActivity.this, "Something went wrong", Toast.LENGTH_LONG).show();
        }
        return super.onOptionsItemSelected(item);
    }
}