package com.example.scstitch;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class CustomerEditMeasurementsActivity extends AppCompatActivity {


    private EditText etEditDressSize, etEditBust, etEditWaist, etEditInseam, etEditHips, etEditAdditional;
    private ProgressBar progressBar;
    private String dressSize, bust, waist, inseam, hips, additional;
    private FirebaseAuth authProfile;
    private Button btnSaveChanges;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_edit_measurements);


        getSupportActionBar().setTitle("Edit customer profile");

        progressBar = findViewById(R.id.progressBar);
        etEditDressSize = findViewById(R.id.etEditDressSize);
        etEditHips = findViewById(R.id.etEditHips);
        etEditBust = findViewById(R.id.etEditBust);
        etEditInseam = findViewById(R.id.etEditInseam);
        etEditWaist = findViewById(R.id.etEditWaist);
        etEditAdditional = findViewById(R.id.etEditAdditional);

        authProfile = FirebaseAuth.getInstance();
        FirebaseUser firebaseUser = authProfile.getCurrentUser();

        FirebaseUser currentFirebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        Toast.makeText(this, "" + currentFirebaseUser.getUid(), Toast.LENGTH_SHORT).show();

        //show profile data
        showProfile(firebaseUser);

        //update profile
        btnSaveChanges = findViewById(R.id.btnSaveChanges);
        btnSaveChanges.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateProfile(firebaseUser);
            }
        });
    }

    private void updateProfile(FirebaseUser firebaseUser) {
        //create database connection
        DAOCustomer dao = new DAOCustomer();

        FirebaseUser currentFirebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        Toast.makeText(this, "" + currentFirebaseUser.getUid(), Toast.LENGTH_SHORT).show();


        //create strings
        CustomerMeasurements user1 = new CustomerMeasurements(etEditDressSize.getText().toString(), etEditWaist.getText().toString(), etEditHips.getText().toString(), etEditInseam.getText().toString(), etEditBust.getText().toString(), etEditAdditional.getText().toString());

        String dressSize = etEditDressSize.getText().toString();
        String hips = etEditHips.getText().toString();
        String waist = etEditWaist.getText().toString();
        String inseam = etEditInseam.getText().toString();
        String bust = etEditBust.getText().toString();


        dao.addMeasurements(currentFirebaseUser.getUid(), user1).addOnSuccessListener(suc ->
        {
            //if successful, bring to profile activity
            //conditions to be met in order to register user
            if (TextUtils.isEmpty(dressSize)) {
                etEditDressSize.setError("Dress size cannot be empty");
                etEditDressSize.requestFocus();
            } else if (TextUtils.isEmpty(bust)) {
                etEditBust.setError("Bust/chest cannot be empty");
                etEditBust.requestFocus();
            } else if (TextUtils.isEmpty(waist)) {
                etEditWaist.setError("Waist cannot be empty");
                etEditWaist.requestFocus();
            } else if (TextUtils.isEmpty(inseam)) {
                etEditInseam.setError("Inseam cannot be empty");
                etEditInseam.requestFocus();
            } else if (TextUtils.isEmpty(hips)) {
                etEditHips.setError("Hips cannot be empty");
                etEditHips.requestFocus();
            } else {
                Toast.makeText(CustomerEditMeasurementsActivity.this, "Changes saved successfully!", Toast.LENGTH_SHORT).show();
                //open profile activity when user registered and not let user return to registration page
                Intent intent = new Intent(CustomerEditMeasurementsActivity.this, CustomerMeasurementsActivity.class);
                intent.setFlags((intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK
                        | Intent.FLAG_ACTIVITY_NEW_TASK));
                startActivity(intent);
                finish();

            }
        });
    }


    //fetch data and set to edit text
    private void showProfile(FirebaseUser firebaseUser) {

        progressBar.setVisibility(View.VISIBLE);
        String userID = firebaseUser.getUid();

        //extracting user reference from database
        DatabaseReference referenceProfile = FirebaseDatabase.getInstance("https://scstitch-5ae62-default-rtdb.firebaseio.com").getReference("Customer");
        referenceProfile.child(userID).child("Customer measurements").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                CustomerMeasurements customerMeasurements = snapshot.getValue(CustomerMeasurements.class);
                if (customerMeasurements != null) {
                    dressSize = customerMeasurements.getDressSize();
                    waist = customerMeasurements.getWaist();
                    bust = customerMeasurements.getBust();
                    hips = customerMeasurements.getHips();
                    inseam = customerMeasurements.getInseam();
                    additional = customerMeasurements.getAdditional();

                    etEditDressSize.setText(dressSize);
                    etEditWaist.setText(waist);
                    etEditBust.setText(bust);
                    etEditHips.setText(hips);
                    etEditInseam.setText(inseam);
                    etEditAdditional.setText(additional);

                } else {
                    Toast.makeText(CustomerEditMeasurementsActivity.this, "Something went wrong", Toast.LENGTH_SHORT).show();
                }
                progressBar.setVisibility(View.GONE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(CustomerEditMeasurementsActivity.this, "Something went wrong", Toast.LENGTH_SHORT).show();
                progressBar.setVisibility(View.GONE);
            }
        });


    }

    //create action bar menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        //inflate menu items
        getMenuInflater().inflate(R.menu.order_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    //when any menu item selected
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item){
        int id = item.getItemId();

        if (id == R.id.menu_refresh){
            //refresh
            startActivity(getIntent());
            finish();
            overridePendingTransition(0, 0);
        } else if (id == R.id.menu_profile){
            Intent intent = new Intent(CustomerEditMeasurementsActivity.this, CustomerProfileActivity.class);
            startActivity(intent);
        }else if (id == R.id.menu_logout) {
            authProfile.signOut();
            Toast.makeText(CustomerEditMeasurementsActivity.this, "Signed out", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(CustomerEditMeasurementsActivity.this, HomeActivity.class);
            startActivity(intent);
            finish(); // close user profile activity
        }else {
            Toast.makeText(CustomerEditMeasurementsActivity.this, "Something went wrong", Toast.LENGTH_LONG).show();
        }
        return super.onOptionsItemSelected(item);
    }
}