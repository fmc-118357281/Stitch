package com.example.scstitch;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class TailorRegisterActivity extends AppCompatActivity {

    //all code in this activity found in youtube video https://www.youtube.com/watch?v=iSsa9OlQJms

    // declare variables
    TextInputEditText etRegEmail;
    TextInputEditText etRegPassword;
    TextView tvLoginHere;
    Button btnRegister;
    ProgressBar progressBar;

    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //Imports the ui from  activity_register_user
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tailor_register);

        getSupportActionBar().setTitle("Tailor registration");

        //Hooks to all xml elements in register_user.xml
        etRegEmail = findViewById(R.id.etRegEmail);
        etRegPassword = findViewById(R.id.etRegPass);
        tvLoginHere = findViewById(R.id.tvLoginHere);
        btnRegister = findViewById(R.id.btnRegister);
        progressBar = findViewById(R.id.progressBar);

        mAuth = FirebaseAuth.getInstance();

        //password code from video https://www.youtube.com/watch?v=vxnjJJkFPCI&list=PLnisUReSm0-kNhfXJHymlIFeyGYHj87tP&index=11
        //show hide password
        ImageView imageViewShowHidePwd = findViewById(R.id.imageView_show_hide_password);
        imageViewShowHidePwd.setImageResource(R.drawable.show_hide_password);
        imageViewShowHidePwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //if pw visible then hide it
                if (etRegPassword.getTransformationMethod().equals(HideReturnsTransformationMethod.getInstance())) {
                    //if password visible then hide it
                    etRegPassword.setTransformationMethod((PasswordTransformationMethod.getInstance()));//change icon
                    //change icon
                    imageViewShowHidePwd.setImageResource(R.drawable.show_hide_password);
                } else {
                    etRegPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    imageViewShowHidePwd.setImageResource((R.drawable.show_password));
                }
            }
        });


        //method create user when register button clicked
        btnRegister.setOnClickListener(view ->{
            createUser();
        });

        //bring user to login activity
        tvLoginHere.setOnClickListener(view ->{
            startActivity(new Intent(TailorRegisterActivity.this, TailorLoginActivity.class));
        });
    }

    private void createUser(){
        // receive data entered by user
        String email = etRegEmail.getText().toString();
        String password = etRegPassword.getText().toString();

        //if statement of conditions to be met
        if (TextUtils.isEmpty(email)){
            etRegEmail.setError("Email cannot be empty");
            etRegEmail.requestFocus();
        }else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(TailorRegisterActivity.this, "Please re-enter your email", Toast.LENGTH_LONG).show();
            etRegEmail.setError("email is invalid");
            etRegEmail.requestFocus();
        }else if (TextUtils.isEmpty(password)){
            etRegPassword.setError("Password cannot be empty");
            etRegPassword.requestFocus();
        }else if (password.length() < 6) {
            Toast.makeText(TailorRegisterActivity.this, "Password should be over 6 digits", Toast.LENGTH_LONG).show();
            etRegPassword.setError("password is too weak");
            etRegPassword.requestFocus();
        }else{
            progressBar.setVisibility(View.VISIBLE);
            //use firebase to register user through authentication
            mAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()){
                        Toast.makeText(TailorRegisterActivity.this, "User registered successfully", Toast.LENGTH_SHORT).show();
                        //open profile activity when user registered and not let user return to registration page
                        Intent intent = new Intent(TailorRegisterActivity.this, TailorCreateProfileActivity.class);
                        intent.setFlags((intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK
                                | Intent.FLAG_ACTIVITY_NEW_TASK));
                        startActivity(intent);
                        finish();

                    }else{
                        //otherwise show error
                        Toast.makeText(TailorRegisterActivity.this, "Registration Error: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                    progressBar.setVisibility(View.GONE);
                }
            });
        }
    }

}