package com.example.scstitch;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

public class UploadProfileImageActivity extends AppCompatActivity {

    //code from https://www.youtube.com/watch?v=Q0jzTItyaLE&list=PLnisUReSm0-kNhfXJHymlIFeyGYHj87tP&index=20

    private ProgressBar progressBar;
    private ImageView imageView;
    private FirebaseAuth authProfile;
    private StorageReference storageReference;
    private FirebaseUser firebaseUser;
    static private final int PICK_IMAGE_REQUEST = 1;
    private Uri uriImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_profile_image);

        getSupportActionBar().setTitle("Upload profile image");


        Button btnUploadImage = findViewById(R.id.btnUploadImage);
        Button btnSelectImage = findViewById(R.id.btnSelectImage);
        progressBar = findViewById(R.id.progressBar);
        imageView = findViewById(R.id.imageView);

        authProfile = FirebaseAuth.getInstance();
        firebaseUser = authProfile.getCurrentUser();

        storageReference = FirebaseStorage.getInstance().getReference("Profile pictures");
        Uri uri = firebaseUser.getPhotoUrl();

        //set Users current DP in imageView(if uploaded already)
        Picasso.with(UploadProfileImageActivity.this).load(uri).into(imageView);
        btnSelectImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFileChooser();
            }
        });

        //upload pic
        btnUploadImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressBar.setVisibility(View.VISIBLE);
                UploadPic();
            }
        });
    }

    private void UploadPic() {
        if (uriImage != null) {
            //save image with uid of current user
            StorageReference fileReference = storageReference.child(authProfile.getCurrentUser().getUid() + "." + getFileExtension(uriImage));
            //upload image to storage
            fileReference.putFile(uriImage).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    fileReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(Uri uri) {
                            Uri downloadUri = uri;
                            firebaseUser = authProfile.getCurrentUser();

                            DatabaseReference root = FirebaseDatabase.getInstance().getReference("Tailor");

                            Model model = new Model(uri.toString());
                            String modelId = root.push().getKey();
                            root.child(modelId).setValue(model);

                            Toast.makeText(UploadProfileImageActivity.this, "Image uploaded successfully", Toast.LENGTH_SHORT).show();

                            //finally set profile pic of user after upload
                           UserProfileChangeRequest profileUpdates = new UserProfileChangeRequest.Builder().setPhotoUri(downloadUri).build();
                            firebaseUser.updateProfile(profileUpdates);
                        }
                    });

                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(UploadProfileImageActivity.this, "Image uploaded successfully", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(UploadProfileImageActivity.this, CustomerProfileActivity.class);
                    finish();
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(UploadProfileImageActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        } else {
           progressBar.setVisibility(View.GONE);
            Toast.makeText(UploadProfileImageActivity.this, "No file selected", Toast.LENGTH_SHORT).show();
        }
    }

    //get file extension of image
    private String getFileExtension(Uri uri) {
        ContentResolver cR = getContentResolver();
        //2 way map used to match meme types
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cR.getType(uri));
    }

    private void openFileChooser () {
        Intent galleryIntent = new Intent();
        galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
        galleryIntent.setType("image/*");
        startActivityForResult(galleryIntent, 2);

    }

        @Override
        protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
            super.onActivityResult(requestCode, resultCode, data);

            if (requestCode == 2 && resultCode == RESULT_OK && data != null) {

                uriImage = data.getData();
                imageView.setImageURI(uriImage);

            }
        }
}
