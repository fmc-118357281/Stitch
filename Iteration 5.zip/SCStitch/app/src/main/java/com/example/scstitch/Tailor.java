package com.example.scstitch;

import android.provider.ContactsContract;

import com.google.firebase.database.Exclude;
import java.io.Serializable;
public class Tailor implements Serializable


{

    //code from youtube video https://www.youtube.com/watch?v=741QCymuky4

        @Exclude
        private String FullName;
        private String Proficiency;
        private String Email;
        private String Address;
        private String Qualification;
        private String RatePerHour;

        //empty public constructor defined to pass data from instant node of database to properties back and forth
    public Tailor() {}


    //constructor to pass the value through
    public Tailor(String FullName, String Proficiency, String Address, String Email, String Qualification, String RatePerHour) {
        this.FullName = FullName;
        this.Proficiency = Proficiency;
        this.Email = Email;
        this.Address = Address;
        this.Qualification = Qualification;
        this.RatePerHour = RatePerHour;
    }

        public String getFullName() {
        return FullName;
    }

        public void setFullName(String fullName) {
        FullName = fullName;
    }

    public String getProficiency() {
        return Proficiency;
    }

    public void setProficiency(String proficiency) {
        Proficiency = proficiency;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

        public String getAddress() {
        return Address;
    }

        public void setAddress(String address) {
        Address = address;
    }

    public String getQualification() {
        return Qualification;
    }

    public void setQualification(String qualification) {
        Qualification = qualification;
    }

    public String getRatePerHour() {
        return RatePerHour;
    }

    public void setRatePerHour(String ratePerHour) {
        RatePerHour = ratePerHour;
    }




    }

