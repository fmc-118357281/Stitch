package com.example.scstitch;

import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import java.util.HashMap;

//code from youtube video https://www.youtube.com/watch?v=741QCymuky4

public class DAOTailor {
    private DatabaseReference databaseReference;

    //connect to database
    public DAOTailor() {
        FirebaseDatabase db = FirebaseDatabase.getInstance("https://scstitch-5ae62-default-rtdb.firebaseio.com/");
        databaseReference = db.getReference(Tailor.class.getSimpleName());
    }

    //push data onto database
    public Task<Void> addUser(String userid, Tailor user) {
        return databaseReference.child(userid).setValue(user);
    }

    //for updating database
    public Task<Void> update(String key, HashMap<String ,Object> hashMap)
    {
        //call child from database
        return databaseReference.child(key).updateChildren(hashMap);
    }
    public Task<Void> remove(String key)
    {
        return databaseReference.child(key).removeValue();
    }
    public Query get()
    {
        return databaseReference;
    }
}