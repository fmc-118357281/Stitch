package com.example.scstitch;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.util.Calendar;

public class CustomerAddMeasurementsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //code found on youtube video https://www.youtube.com/watch?v=741QCymuky4
        // connect to xml file
        setContentView(R.layout.activity_customer_add_measurements);

        getSupportActionBar().setTitle("Add measurements");

        //set which ids relate to each variable
        final EditText etDressSize = findViewById(R.id.etDressSize);
        final EditText etWaist = findViewById(R.id.etWaist);
        final EditText etHips = findViewById(R.id.etHips);
        final EditText etInseam = findViewById(R.id.etInseam);
        final EditText etBust = findViewById(R.id.etBust);
        final EditText etAdditional = findViewById(R.id.etAdditional);
        final Button btnLogOut = findViewById(R.id.btnLogOut);
        final ProgressBar progressBar = findViewById(R.id.progressBar);


        //log out button functionality
        btnLogOut.setOnClickListener(view -> {
            startActivity(new Intent(CustomerAddMeasurementsActivity.this, HomeActivity.class));
        });

        //save measurements button functionality
        Button btnSaveMeasurements = findViewById(R.id.btnSaveMeasurements);
        //create database connection
        DAOCustomerMeasurements dao = new DAOCustomerMeasurements();
        btnSaveMeasurements.setOnClickListener(v ->
        {

            //create strings
            CustomerMeasurements user = new CustomerMeasurements(etDressSize.getText().toString(), etWaist.getText().toString(), etHips.getText().toString(), etInseam.getText().toString(), etBust.getText().toString(), etAdditional.getText().toString());

            String dressSize = etDressSize.getText().toString();
            String Waist = etWaist.getText().toString();
            String Hips = etHips.getText().toString();
            String Inseam = etInseam.getText().toString();
            String Bust = etBust.getText().toString();

            //if successful, bring to profile activity
            dao.add(user).addOnSuccessListener(suc ->
            {
                //conditions to be met in order to register user
                if  (etDressSize.length() > 2) {
                    etDressSize.setError("Invalid dress size");
                    etDressSize.requestFocus();
                }else if (TextUtils.isEmpty(dressSize)) {
                    etDressSize.setError("Dress size cannot be empty");
                    etDressSize.requestFocus();
                }else if (TextUtils.isEmpty(Waist)) {
                    etWaist.setError("Waist measurement cannot be empty");
                    etWaist.requestFocus();
                }else if (TextUtils.isEmpty(Hips)) {
                    etHips.setError("Hips measurement cannot be empty");
                    etHips.requestFocus();
                }else if (TextUtils.isEmpty(Inseam)) {
                    etInseam.setError("Inseam measurement cannot be empty");
                    etInseam.requestFocus();
                }else if (TextUtils.isEmpty(Bust)) {
                    etBust.setError("Bust measurement cannot be empty");
                    etBust.requestFocus();
                }else {
                    progressBar.setVisibility(View.VISIBLE);
                    Toast.makeText(this, "Your measurements have been saved!", Toast.LENGTH_SHORT).show();


                    // bring user to profile page
                    // prevent user from returning back to create profile activity once registration successful
                    Intent intent = new Intent(CustomerAddMeasurementsActivity.this, CustomerMeasurementsActivity.class);
                    intent.setFlags((intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK
                            | Intent.FLAG_ACTIVITY_NEW_TASK));
                    startActivity(intent);
                    finish();
                }
            }).addOnFailureListener(er ->
            {
                Toast.makeText(this, "Error saving measurements" + er.getMessage(), Toast.LENGTH_SHORT).show();
            });
            progressBar.setVisibility(View.GONE);

        });


    }
}


