package com.example.scstitch;

//all code from https://www.youtube.com/watch?v=MnJg1f25h_g&list=PLnisUReSm0-kNhfXJHymlIFeyGYHj87tP&index=14

public class ReadWriteUserDetails {
    public String DOB, address, phone, qualification;

    //constructor
    public ReadWriteUserDetails(String textType){};

    public ReadWriteUserDetails(String textDOB, String textPhone, String textAddress, String textQualification){
        this.DOB = textDOB;
        this.address = textAddress;
        this.phone = textPhone;
        this.qualification = textQualification;

    }
}
