package com.example.scstitch;

import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;

import java.util.HashMap;

public class DAOCustomerMeasurements {
    private DatabaseReference databaseReference;

    //
    public DAOCustomerMeasurements() {
        FirebaseDatabase db = FirebaseDatabase.getInstance();
        databaseReference = db.getReference(CustomerMeasurements.class.getSimpleName());
    }

    //push data onto database
    public Task<Void> add(CustomerMeasurements user) {
        return databaseReference.push().setValue(user);

    }

    //for updating database
    public Task<Void> update(String key, HashMap<String ,Object> hashMap)
    {
        //call child from database
        return databaseReference.child(key).updateChildren(hashMap);
    }
    public Task<Void> remove(String key)
    {
        return databaseReference.child(key).removeValue();
    }
    public Query get()
    {
        return databaseReference;
    }
}


