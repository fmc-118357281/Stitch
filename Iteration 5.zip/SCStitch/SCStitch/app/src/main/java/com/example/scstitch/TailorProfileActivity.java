package com.example.scstitch;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class TailorProfileActivity extends AppCompatActivity {

    //all code from https://www.youtube.com/watch?v=MnJg1f25h_g&list=PLnisUReSm0-kNhfXJHymlIFeyGYHj87tP&index=14

    private TextView tvWelcome, tvFullName, tvEmail, tvAddress, tvDOB, tvPhone, tvQualification;
    private ProgressBar progressBar;
    private String fullName, address, DOB, phone, email, qualification;
    private ImageView imageview;
    private FirebaseAuth authProfile;
    private Button btnLogOut;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tailor_profile);

        getSupportActionBar().setTitle("Home");

        tvWelcome = findViewById(R.id.tvWelcome);
        tvFullName = findViewById(R.id.tvFullName);
        tvEmail = findViewById(R.id.tvEmail);
        tvAddress = findViewById(R.id.tvAddress);
        tvDOB = findViewById(R.id.tvDOB);
        tvPhone = findViewById(R.id.tvPhone);
        tvQualification = findViewById(R.id.tvQualification);
        progressBar = findViewById(R.id.progressBar);
        btnLogOut = findViewById(R.id.btnLogOut);

        authProfile = FirebaseAuth.getInstance();
        FirebaseUser firebaseUser = authProfile.getCurrentUser();

        if (firebaseUser == null) {
            Toast.makeText(TailorProfileActivity.this, "Error occured, Profile details unattainable at this moment", Toast.LENGTH_LONG).show();
        } else {
            progressBar.setVisibility(View.VISIBLE);
            showUserProfile(firebaseUser);

        }
    }

    private void showUserProfile(FirebaseUser firebaseUser){
        String userID = firebaseUser.getUid();

        //extracting user reference from database
        DatabaseReference referenceProfile = FirebaseDatabase.getInstance().getReference("Tailor");
        referenceProfile.child(userID).addListenerForSingleValueEvent(new ValueEventListener(){
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot){
                ReadWriteUserDetails readUserDetails = snapshot.getValue(ReadWriteUserDetails.class);
                if (readUserDetails != null){
                    fullName = firebaseUser.getDisplayName();
                    email = firebaseUser.getEmail();
                    address = readUserDetails.address;
                    DOB = readUserDetails.DOB;
                    phone = readUserDetails.phone;
                    qualification = readUserDetails.qualification;

                    tvWelcome.setText("Welcome, " + fullName + "!");
                    tvFullName.setText(fullName);
                    tvEmail.setText(email);
                    tvAddress.setText(address);
                    tvDOB.setText(DOB);
                    tvPhone.setText(phone);
                    tvQualification.setText(qualification);
                }
            }

            //triggered in event of failure due to firebase rules
            @Override
            public void onCancelled(@NonNull DatabaseError error){
                Toast.makeText(TailorProfileActivity.this, "Something went wrong", Toast.LENGTH_LONG).show();
            }


        });

        //log out button functionality
        btnLogOut.setOnClickListener(view -> {
            startActivity(new Intent(TailorProfileActivity.this, HomeActivity.class));
        });




    }
}

