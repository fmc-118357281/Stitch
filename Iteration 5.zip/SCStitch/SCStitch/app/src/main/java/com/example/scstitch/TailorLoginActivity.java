package com.example.scstitch;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthInvalidUserException;
import com.google.firebase.auth.FirebaseUser;

//all code in this activity found in youtube video https://www.youtube.com/watch?v=iSsa9OlQJms
public class TailorLoginActivity extends AppCompatActivity {

    //delcare variables
    TextInputEditText etLoginEmail;
    TextInputEditText etLoginPassword;
    TextView tvRegisterHere;
    Button btnLogin;
    ProgressBar progressBar;
    String TAG = "LoginActivity";


    FirebaseAuth authProfile;
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //Imports the ui from  activity_register_user
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tailor_login);

        getSupportActionBar().setTitle("Tailor login");

        //Hooks to all xml elements in register_user.xml
        etLoginEmail = findViewById(R.id.etLoginEmail);
        etLoginPassword = findViewById(R.id.etLoginPass);
        tvRegisterHere = findViewById(R.id.tvRegisterHere);
        btnLogin = findViewById(R.id.btnLogin);
        progressBar = findViewById(R.id.progressBar);

        mAuth = FirebaseAuth.getInstance();


        //password code from https://www.youtube.com/watch?v=vxnjJJkFPCI&list=PLnisUReSm0-kNhfXJHymlIFeyGYHj87tP&index=11
        //show hide password
        ImageView imageViewShowHidePwd = findViewById(R.id.imageView_show_hide_password);
        imageViewShowHidePwd.setImageResource(R.drawable.show_hide_password);
        imageViewShowHidePwd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //if pw visible then hide it
                if (etLoginPassword.getTransformationMethod().equals(HideReturnsTransformationMethod.getInstance())) {
                    //if password visible then hide it
                    etLoginPassword.setTransformationMethod((PasswordTransformationMethod.getInstance()));
                    //change icon
                    imageViewShowHidePwd.setImageResource(R.drawable.show_hide_password);
                } else {
                    etLoginPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    imageViewShowHidePwd.setImageResource((R.drawable.show_password));
                }
            }
        });

        //method loginUser called when log in button clicked
        btnLogin.setOnClickListener(view -> {
            loginUser();
        });
        //bring user to register activity
        tvRegisterHere.setOnClickListener(view ->{
            startActivity(new Intent(TailorLoginActivity.this, TailorRegisterActivity.class));
        });
    }

    //loginUser method
    private void loginUser(){
        // receive data entered by user
        String email = etLoginEmail.getText().toString();
        String password = etLoginPassword.getText().toString();

        //if statement of conditions to be met
        if (TextUtils.isEmpty(email)){
            etLoginEmail.setError("Email cannot be empty");
            etLoginEmail.requestFocus();
        }else if (TextUtils.isEmpty(password)){
            etLoginPassword.setError("Password cannot be empty");
            etLoginPassword.requestFocus();
        }else{
            progressBar.setVisibility(View.VISIBLE);
            //use firebase to register user through authentication
            mAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()){
//
//                        //get instance of current user
//                        FirebaseUser firebaseUser = authProfile.getCurrentUser();

                        //open profile activity
                        Toast.makeText(TailorLoginActivity.this, "User logged in successfully", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(TailorLoginActivity.this, TailorProfileActivity.class));

                    }else{
                        //show error
                        try {
                            throw task.getException();
                        } catch(FirebaseAuthInvalidUserException e) {
                            etLoginEmail.setError("User does not exist or is no longer valid. Please try again");
                            etLoginEmail.requestFocus();
                        } catch (FirebaseAuthInvalidCredentialsException e) {
                            etLoginPassword.setError("Invalid credentials, please re-enter");
                            etLoginPassword.requestFocus();
                        } catch (Exception e) {
                            Log.e(TAG, e.getMessage());
                            Toast.makeText(TailorLoginActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();

                        }

                    }
                    progressBar.setVisibility(View.GONE);
                }
            });
        }
    }

}
