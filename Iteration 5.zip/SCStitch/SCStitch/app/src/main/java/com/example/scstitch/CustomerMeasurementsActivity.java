package com.example.scstitch;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class CustomerMeasurementsActivity extends AppCompatActivity {


    private Button btnAddMeasurements;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_measurements);


        getSupportActionBar().setTitle("Customer measurements");

        btnAddMeasurements = findViewById(R.id.btnAddMeasurements);

        //view measurements button functionality
        btnAddMeasurements.setOnClickListener(view -> {
            startActivity(new Intent(CustomerMeasurementsActivity.this, CustomerAddMeasurementsActivity.class));
        });
    }


}