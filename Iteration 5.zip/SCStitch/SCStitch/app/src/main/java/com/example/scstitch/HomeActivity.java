package com.example.scstitch;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        getSupportActionBar().setTitle("Stitch");

        final Button btnCustomer = findViewById(R.id.btnCustomer);
        //log out button functionality
        btnCustomer.setOnClickListener(view -> {
            startActivity(new Intent(HomeActivity.this, CustomerLoginActivity.class));
        });

        final Button btnTailor = findViewById(R.id.btnTailor);
        //log out button functionality
        btnTailor.setOnClickListener(view -> {
            startActivity(new Intent(HomeActivity.this, TailorLoginActivity.class));
        });

    }
}