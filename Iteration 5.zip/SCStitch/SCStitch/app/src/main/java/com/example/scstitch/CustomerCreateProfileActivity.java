package com.example.scstitch;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.icu.text.LocaleDisplayNames;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.lang.reflect.Field;
import java.util.Calendar;


public class CustomerCreateProfileActivity extends AppCompatActivity {

    private DatePickerDialog picker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //code found on youtube video https://www.youtube.com/watch?v=741QCymuky4
        // connect to xml file
        setContentView(R.layout.activity_create_profile_customer);

        getSupportActionBar().setTitle("Profile");

        //set which ids relate to each variable
        final EditText etRegFullName = findViewById(R.id.etRegFullName);
        final EditText etRegDOB = findViewById(R.id.etRegDOB);
        final EditText etRegAddress = findViewById(R.id.etRegAddress);
        final EditText etRegPhone = findViewById(R.id.etRegPhone);
        final Button btnLogOut = findViewById(R.id.btnLogOut);
        final ProgressBar progressBar = findViewById(R.id.progressBar);

        //setting date picker for edit text
        etRegDOB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar calendar = Calendar.getInstance();
                int day = calendar.get(Calendar.DAY_OF_MONTH);
                int month = calendar.get(Calendar.MONTH);
                int year = calendar.get(Calendar.YEAR);

                //date picker dialog
                picker = new DatePickerDialog(CustomerCreateProfileActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                    etRegDOB.setText(dayOfMonth + "/" + (month + 1) + "/" + year);
                    }
                }, year, month, day);
                picker.show();
            }
        });

        //log out button functionality
        btnLogOut.setOnClickListener(view -> {
            startActivity(new Intent(CustomerCreateProfileActivity.this, HomeActivity.class));
        });

        //create profile button functionality
        Button btnCreateProfile = findViewById(R.id.btnCreateProfile);
        //create database connection
        DAOCustomer dao = new DAOCustomer();
        btnCreateProfile.setOnClickListener(v ->
        {

            //create strings
            Customer user = new Customer(etRegFullName.getText().toString(), etRegDOB.getText().toString(), etRegAddress.getText().toString(), etRegPhone.getText().toString());

            String fullName = etRegFullName.getText().toString();
            String address = etRegAddress.getText().toString();

                //if successful, bring to profile activity
                dao.add(user).addOnSuccessListener(suc ->
                {
                    //conditions to be met in order to register user
                    if  (etRegPhone.length() != 10) {
                        etRegPhone.setError("Phone number should be 10 digits");
                        etRegPhone.requestFocus();
                    }else if(TextUtils.isEmpty(address)) {
                        etRegAddress.setError("Email cannot be empty");
                        etRegAddress.requestFocus();
                }else if (TextUtils.isEmpty(fullName)) {
                        etRegFullName.setError("Full name cannot be empty");
                        etRegFullName.requestFocus();
                    }else {//if (etRegDOB.length() != 10) {
//                        etRegDOB.setError("Invalid date of birth");
//                        etRegDOB.requestFocus();
//                    } else {
                        progressBar.setVisibility(View.VISIBLE);
                        Toast.makeText(this, "Your customer profile has been created", Toast.LENGTH_SHORT).show();


                        // bring user to profile page
                        // prevent user from returning back to create pofile activity once registration successful
                        Intent intent = new Intent(CustomerCreateProfileActivity.this, CustomerProfileActivity.class);
                        intent.setFlags((intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK
                                | Intent.FLAG_ACTIVITY_NEW_TASK));
                        startActivity(intent);
                        finish();
                    }
                }).addOnFailureListener(er ->
                {
                    Toast.makeText(this, "Error saving measurements" + er.getMessage(), Toast.LENGTH_SHORT).show();
                });
                progressBar.setVisibility(View.GONE);

            });


//trying to load details of user profile

//        //get firebase user
//        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
//
////get reference
//        DatabaseReference ref = FirebaseDatabase.getInstance().getReference(Customer).child(user.getUid());
//
////grab info
//        ref.addListenerForSingleValueEvent(new ValueEventListener() {
//            @Override
//            public void onDataChange(DataSnapshot dataSnapshot) {
//                final Customer tempProfile = new Customer(); //this is my user_class Class
//                final Field[] fields = tempProfile.getClass().getDeclaredFields();
//                for(Field field : fields){
//                    Log.i(TAG, field.getName() + ": " + dataSnapshot.child(field.getName()).getValue());
//                }
//            }
//
//            @Override
//            public void onCancelled(DatabaseError databaseError) {
//            }
//        });
        }
    }


