package com.example.scstitch;

import com.google.firebase.database.Exclude;
import java.io.Serializable;
public class Tailor implements Serializable

        //code from youtube video https://www.youtube.com/watch?v=741QCymuky4
{
    @Exclude
    private String FullName;
    private String Id;
    private String DOB;
    private String Phone;
    private String Address;
    private String Qualification;

    //empty public constructor defined to pass data from instant node of database to properties back and forth
    public Tailor() {}

    //constructor to pass the value through
    public Tailor(String FullName, String DOB, String Phone, String Address, String Qualification) {
        this.FullName = FullName;
        this.Id = Id;
        this.DOB = DOB;
        this.Phone = Address;
        this.Address = Phone;
        this.Qualification = Qualification;
    }




    public String getFullName() {
        return FullName;
    }

    public void setFullName(String fullName) {
        FullName = fullName;
    }

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }

    public String getDOB() {
        return DOB;
    }

    public void setDOB(String DOB) {
        this.DOB = DOB;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String phone) {
        Phone = phone;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getQualification() { return Qualification; }

    public void setQualification(String qualification) { Qualification = qualification; }


}
